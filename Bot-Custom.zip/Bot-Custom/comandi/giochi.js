const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageButton, MessageActionRow } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('giochi')
        .setDescription('Comando setup giochi | Accessibile solo allo staff'),
        
    async execute(interaction, client) {
        if (interaction.member?.roles.cache.has(client.config.ruoli.staff)){
            const embed = new client.discord.MessageEmbed()
                .setTitle("**⮞｜OTTIENI RUOLI｜⮜**")
                .setDescription("**Reagisci per ottenere i ruoli:**\n\n✅ ➥ Attesa Background")
                .setColor("YELLOW")
                .setTimestamp()
                
			const message = await interaction.channel.send({ embeds: [embed], fetchReply: true });
			message.react('✅');
            
        }else
            interaction.reply({content: "Non hai il permesso di farlo", ephemeral: true});
    }
}