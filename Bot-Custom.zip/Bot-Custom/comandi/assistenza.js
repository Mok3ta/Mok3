const { SlashCommandBuilder } = require('@discordjs/builders');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('assistenza')
        .setDescription('Richiedi assistenza'),
    async execute(interaction, client) {
		interaction.reply({content:`**<@${interaction.user.id}> ha richiesto assistenza <@&${client.config.ruoli.staff}>**`});
    }
}