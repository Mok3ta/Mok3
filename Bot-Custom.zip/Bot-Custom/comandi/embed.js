const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Invia un messaggio in formato embed.'),
  async execute(interaction) {
    const embedMessage = new MessageEmbed()
      .setColor('#ff00ff')
      .setTitle('TITOLO')
      .setDescription('DESCRIZIONE')
      .setThumbnail('URL_IMMAGINE')
      .addFields(
        { name: 'Campo 1', value: 'Descrizione 1' },
        { name: 'Campo 2', value: 'Descrizione 2' },
        { name: 'Campo 3', value: 'Descrizione 3' },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embedMessage] });
  },
};
