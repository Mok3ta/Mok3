const { SlashCommandBuilder } = require('@discordjs/builders');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Cancella Messaggi | Accessibile solo allo staff')
        .addStringOption(option =>
            option.setName('amount')
                .setDescription('Quantità: ')
                .setRequired(true)),
        
    async execute(interaction, client) {
		if (interaction.member?.roles.cache.has(client.config.ruoli.staff)){
			 interaction.channel.bulkDelete(interaction.options.getString("amount"), true);
			const embed = new client.discord.MessageEmbed()
				.setDescription(`**${interaction.options.getString("amount")} messaggi eliminati**`)
				.setColor("GREEN")
				.setTimestamp()
			interaction.reply({embeds: [embed], ephemeral: true});
		}else
			interaction.reply({content: "Non puoi farlo", ephemeral: true})
    }
}